function GetPost(cb) {
    let xmlhttpReq = new XMLHttpRequest();
    xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlhttpReq.onreadystatechange = () => {
        if (xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200) {
            cb(null, JSON.parse(xmlhttpReq.responseText));
        } else if (xmlhttpReq.readyState != 4 && xmlhttpReq.status != 200) {
            cb(true)
        }
    }
    xmlhttpReq.send();
}