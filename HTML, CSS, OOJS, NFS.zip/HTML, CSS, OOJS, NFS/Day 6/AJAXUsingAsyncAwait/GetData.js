function getPost() {
    return new Promise((res, rej) => {
        let xmlhttpReq = new XMLHttpRequest();
        xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
        xmlhttpReq.onreadystatechange = () => {
            if (xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200) {
                res(xmlhttpReq.responseText);
            } else if (xmlhttpReq.readyState != 4 && xmlhttpReq.status != 200) {
                rej(true)
            }
        }
        xmlhttpReq.send();
        setTimeout(() => {
            res("log after 3 seconds");
        }, 3000);
    })
}