console.log("Hello World");

async function getCourse() {
    try {
        let courses = await fetch('http://localhost:3000/courses');
        if (courses.ok) {
            courses = await courses.json();
            let coursesList = document.getElementById('coursesList');
            let html = '';
            for (const course of courses) {
                let starts = '';
                for (let index = 0; index < course.rating; index++) {
                    starts += '<i class="fa-solid fa-star"></i>'
                }
                html += `<div class="card m-2" style="width: 18rem;">
                <img src="${course.imageUrl}" class="card-img-top mt-1" alt="...">
                <div class="card-body">
                  <h5 class="card-title">${course.title}</h5>
                    <p>${starts}</p>
                  <p>Rs. ${course.price}</p>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary"><i class="fa-solid fa-thumbs-up"></i>${course.likes}</button>
                    <button class="btn btn-danger"><i class="fa-solid fa-trash-can"></i></button>
                </div>
              </div>`;

            }
            coursesList.innerHTML = html;
        }
    } catch (error) {
        console.log(error);
    }
   
}

getCourse();
