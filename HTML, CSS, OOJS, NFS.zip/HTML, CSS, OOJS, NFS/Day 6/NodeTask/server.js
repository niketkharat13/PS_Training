const express = require('express');
const app = express();
const port = 3000;
const path = require('path');
var courses = require('./models/courses.model');

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json())
app.get('/courses', (req, res) => {
    // res.send(JSON.stringify(courses, null ,5))
    res.json(courses);
})

app.get('/', (req, res) => {
    // res.sendFile('Courses.html', {root: __dirname})
    res.sendFile('finalCourses.html', {root: __dirname})

})

app.delete('/courses/:id', (req, res) => {
    let cId = req.params.id;
    courses = courses.filter(c => c.id != cId);
    res.send({
        msg:"success",
        data: courses
    })
})

app.post('/newcourse', (req, res) => {
    let course = req.body;
    courses = [...courses, course];
    res.send({
        msg: 'success',
        data: courses
    })
})

// app.get('/newCourse', (req, res) => {
//     res.sendFile("newCourse.html", {root: __dirname})
// })


app.listen(port, () => console.log(`Courses server started running on ${port}`))