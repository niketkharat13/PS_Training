//console.log(this); // prints DedicatedWorkerGlobalScope
// 1. No access to window object / document
// 2. No access to global variable from main thread
// 3. No Access to localStorage/sessionStorage
// 4. Access to IndexedDB  / XMLHttpRequest / fetch
onmessage = function (msg) {
    //   console.log(msg.data);
    var largeArray = [];
    for (let i = 0; i < 7000; i++) {
      largeArray[i] = [];
      for (let j = 0; j < 8000; j++) {
        largeArray[i][j] = Math.random();
      }
    }
    postMessage(largeArray[3000][3000]);
};