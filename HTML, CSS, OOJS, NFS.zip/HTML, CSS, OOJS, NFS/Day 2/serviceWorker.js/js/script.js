if (navigator.serviceWorker) {
    document.addEventListener('load', () => {
        this.navigator.serviceWorker.register('../serviceWorker.js')
        .then(console.log("registered"))
        .catch(console.log("error registering"))
    })
}