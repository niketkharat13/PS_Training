var cacheName = "v1";
var cacheAssets = ['Index.html', 'About.js'];
self.addEventListener('install', function(e) {
    e.waitUntil(
        caches.open(cacheName)
        .then(() => cache.addAll(cacheAssets))
        .then(() => self.skipWaiting())
    )
})


self.addEventListener("activate", () => {
    console.log("Activated");
    e.waitUntil(
        caches.keys().then((cName) => {
            return Promise.all(
                cName.map(c => {
                    if (c != cacheName) {
                        return caches.delete(c)
                    }
                })
            )
        })
    )
})


self.addEventListener("fetch", (e) => {
    console.log("Fetching");
    e.respondWith(
        fetch(e.request)
        .catch(() => {
            return caches.match(e.request)
        })
    )
})