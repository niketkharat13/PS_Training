export var Add = (x, y) => x + y;

export class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}