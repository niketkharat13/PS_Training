import { Add, Point } from "./module";

console.log(`Addition is : ${Add(20, 50)}`);

var point = new Point(100, 200);